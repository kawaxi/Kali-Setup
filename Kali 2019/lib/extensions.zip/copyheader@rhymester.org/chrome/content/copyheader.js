var copyheader = (function() {

var self = {};

//==========================================================================
// 全てのタブに関する事項
//==========================================================================

/*-------------------------------------------
 * すべてのヘッダーデータをコピー
 */
self.copyAllHederData = function() 
{
    var cpb  = getCpb();
	var browser = getBrowser();
	var tabNum = browser.gBrowser.mTabs.length;
	var txt = "";
	for(var i = 0; i<tabNum; i++)
	{
		var b = browser.gBrowser.getBrowserAtIndex(i);
		var title = getTitle(b.contentDocument);
		var url= getURL(b.contentDocument);
		var d = getDescription(b.contentDocument);
		var k = getKeyWords(b.contentDocument);
		txt += title + url + d + k + getCrlf();
		cpb.copyString(txt);
	}	
}

/*-------------------------------------------
 * すべてのタイトルとURLをコピー
 */
self.copyAllTitle = function()
{
    var cpb  = getCpb();
	var browser = getBrowser();
	var txt = "";
	var tabNum = browser.gBrowser.mTabs.length;
	for(var i = 0; i<tabNum; i++)
	{
		var b = browser.gBrowser.getBrowserAtIndex(i);
		var title = getTitle(b.contentDocument);
		var url= getURL(b.contentDocument);
		txt += title + url + getCrlf();
		cpb.copyString(txt);
	}	
}

/*-------------------------------------------
 * すべてのURLをコピー
 */
self.copyAllURL = function()
{
    var cpb  = getCpb();
	var browser = getBrowser();
	var txt = "";
	var tabNum = browser.gBrowser.mTabs.length;
	for(var i = 0; i<tabNum; i++)
	{
		var b = browser.gBrowser.getBrowserAtIndex(i);
		var url= getURL(b.contentDocument);
		txt += url + getCrlf();
		cpb.copyString(txt);
	}	
}

/*-------------------------------------------
 * すべてのディスクリプションをコピー
 */
self.copyAllDescription = function() 
{
    var cpb  = getCpb();
	var browser = getBrowser();
	var txt = "";
	var tabNum = browser.gBrowser.mTabs.length;
	for(var i = 0; i<tabNum; i++)
	{
		var b = browser.gBrowser.getBrowserAtIndex(i);
		var d = getDescription(b.contentDocument);
		txt += d + getCrlf();
		cpb.copyString(txt);
	}	
}

/*-------------------------------------------
 * すべてのキーワードをコピー
 */
self.copyAllKeywords = function() 
{
    var cpb  = getCpb();
	var browser = getBrowser();
	var txt = "";
	var tabNum = browser.gBrowser.mTabs.length;
	for(var i = 0; i<tabNum; i++)
	{
		var b = browser.gBrowser.getBrowserAtIndex(i);
		var k = getKeyWords(b.contentDocument);
		txt += k + getCrlf();
		cpb.copyString(txt);
	}	
}


//==========================================================================
// 個別のタブに関する事項
//==========================================================================

/*-------------------------------------------
 * ヘッダーデータをコピー
 */
self.copyHederData = function() 
{
    var doc  = window._content.document;
    var txt  = getTitle(doc) + getURL(doc) + getDescription(doc) + getKeyWords(doc) + getCrlf();
    var cpb  = getCpb();
    cpb.copyString(txt);
}

/*-------------------------------------------
 * タイトルとURLをコピー
 */
self.copyTitle = function() 
{
    var doc  = window._content.document;
    var txt  = getTitle(doc) + getURL(doc) + getCrlf();
    var cpb  = getCpb();
    cpb.copyString(txt);
}

/*-------------------------------------------
 * URLをコピー
 */
self.copyURL = function() 
{
    var doc  = window._content.document;
    var txt  = getURL(doc) + getCrlf();
    var cpb  = getCpb();
    cpb.copyString(txt);
}

/*-------------------------------------------
 * ディスクリプションをコピー
 */
self.copyDescription = function() 
{
    var doc  = window._content.document;
	var d = getDescription(doc);
	txt = d + getCrlf();
    var cpb  = getCpb();
    cpb.copyString(txt);
}

/*-------------------------------------------
 * キーワードをコピー
 */
self.copyKeywords = function() 
{
    var doc  = window._content.document;
	var k = getKeyWords(doc);
	txt = k + getCrlf();
    var cpb  = getCpb();
    cpb.copyString(txt);
}


//==========================================================================
// データ取得に関する事項
//==========================================================================

/*-------------------------------------------
 * タイトルの取得
 *　@param  doc    Document
 * @return title  
 */
function getTitle(doc)
{
	var bundle = document.getElementById("copyheader-bundle");
	var title = doc.title;
	var txt = (title != null || title != "") ? title : bundle.getString("NO_TITLE") ;
	return txt + getCrlf();
}

/*-------------------------------------------
 * URLの取得
 *　@param  doc  Document
 * @return URL  
 */
function getURL(doc)
{
	var bundle = document.getElementById("copyheader-bundle");
	var url = doc.location.href;
	var txt = (url != null || url != "") ? url : bundle.getString("NO_URL") ;
	return txt + getCrlf();
}

/*-------------------------------------------
 * Descriptionの取得
 *　@param  doc    		Document
 * @return Description  
 */
function getDescription(doc)
{
	var bundle = document.getElementById("copyheader-bundle");
	var metas = doc.getElementsByTagName("meta");
	var d;
    for (var i=0; i < metas.length; i++) {
      if (metas[i].name.match(/description/i)) {
        d = metas[i].content;
      }
    }
	var txt = (d != null) ? d :  bundle.getString("NO_DESCRIPTION") ;
	return txt + getCrlf();
}

/*-------------------------------------------
 * keywordsの取得
 *　@param  doc    	Document
 * @return keywords  
 */
function getKeyWords(doc)
{
	var bundle = document.getElementById("copyheader-bundle");
	var k;
    var metas = doc.getElementsByTagName("meta");
	for (var i=0; i < metas.length; i++) {
      if (metas[i].name.match(/keywords/i)) {
        k = metas[i].content;
      }
    }
	var txt = (k != null) ? k :  bundle.getString("NO_KEYWORDS") ;
	return txt + getCrlf();
}

/*-------------------------------------------
 * 改行コードの取得
 * @return crlf  
 */
function getCrlf()
{
    var crlf = (navigator.platform.indexOf("Win") != -1) ? "\r\n" : "\n";
	return crlf;
}

/*-------------------------------------------
 * クリップボードの取得
 * @return cpb  
 */
function getCpb()
{
    var cpb  = Components.classes["@mozilla.org/widget/clipboardhelper;1"].getService(Components.interfaces.nsIClipboardHelper);
	return cpb;
}

/*-------------------------------------------
 * ブラウザの取得
 * @return browser  
 */
function getBrowser()
{
	var WindowMediator = Components.classes['@mozilla.org/appshell/window-mediator;1'].getService(Components.interfaces.nsIWindowMediator);
	var browser = WindowMediator.getMostRecentWindow('navigator:browser');
	return browser;
}

return self;

})();



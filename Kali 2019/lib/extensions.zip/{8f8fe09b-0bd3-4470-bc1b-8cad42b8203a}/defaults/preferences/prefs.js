pref("extensions.{8f8fe09b-0bd3-4470-bc1b-8cad42b8203a}.description", "chrome://livehttpheaders/locale/livehttpheaders.properties");

/** 
 * HackBar namespace. 
 */  
if ( "undefined" == typeof( HackBar ) ) {  
  var HackBar = {};
}; 
